#ifndef MPITEST_GCOMMS
#define MPITEST_GCOMMS

void MakeComms ( MPI_Comm *, int, int *, int );
void FreeComms ( MPI_Comm *, int );
#endif
